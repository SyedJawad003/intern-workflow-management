const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const Intern = require("../models/Intern");

// Helper: validate ObjectId
const isValidObjectId = (id) => mongoose.Types.ObjectId.isValid(id);

// POST /api/interns — Create intern
router.post("/", async (req, res, next) => {
  try {
    const intern = new Intern(req.body);
    await intern.save();
    res.status(201).json({ success: true, data: intern });
  } catch (err) {
    next(err);
  }
});

// GET /api/interns — List with search, filter, pagination
router.get("/", async (req, res, next) => {
  try {
    const {
      search = "",
      role,
      status,
      page = 1,
      limit = 10,
      sortBy = "createdAt",
      sortOrder = "desc",
    } = req.query;

    const query = {};

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
      ];
    }

    if (role) query.role = role;
    if (status) query.status = status;

    const pageNum = Math.max(1, parseInt(page));
    const limitNum = Math.min(100, Math.max(1, parseInt(limit)));
    const skip = (pageNum - 1) * limitNum;
    const sort = { [sortBy]: sortOrder === "asc" ? 1 : -1 };

    const [interns, total] = await Promise.all([
      Intern.find(query).sort(sort).skip(skip).limit(limitNum),
      Intern.countDocuments(query),
    ]);

    res.json({
      success: true,
      data: interns,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (err) {
    next(err);
  }
});

// GET /api/interns/:id — Single intern
router.get("/:id", async (req, res, next) => {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid ID format" });
    }

    const intern = await Intern.findById(req.params.id);
    if (!intern) {
      return res
        .status(404)
        .json({ success: false, message: "Intern not found" });
    }

    res.json({ success: true, data: intern });
  } catch (err) {
    next(err);
  }
});

// PATCH /api/interns/:id — Update intern
router.patch("/:id", async (req, res, next) => {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid ID format" });
    }

    const intern = await Intern.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    if (!intern) {
      return res
        .status(404)
        .json({ success: false, message: "Intern not found" });
    }

    res.json({ success: true, data: intern });
  } catch (err) {
    next(err);
  }
});

// DELETE /api/interns/:id — Delete intern
router.delete("/:id", async (req, res, next) => {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid ID format" });
    }

    const intern = await Intern.findByIdAndDelete(req.params.id);
    if (!intern) {
      return res
        .status(404)
        .json({ success: false, message: "Intern not found" });
    }

    res.json({
      success: true,
      message: "Intern deleted successfully",
      data: intern,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
