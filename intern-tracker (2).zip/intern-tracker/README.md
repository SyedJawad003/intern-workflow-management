# 🗂 Intern Tracker — MERN Stack App

A full-stack intern management system built with **MongoDB, Express, React, and Node.js**.

---

## 📁 Project Structure

```
intern-tracker/
├── server/                 # Node.js + Express backend
│   ├── models/
│   │   └── Intern.js       # Mongoose schema
│   ├── routes/
│   │   └── interns.js      # CRUD route handlers
│   ├── middleware/
│   │   └── errorHandler.js # Centralized error handling
│   ├── server.js           # App entry point
│   ├── .env.example        # Environment variable template
│   └── package.json
│
├── client/                 # React + Vite frontend
│   ├── src/
│   │   ├── components/
│   │   │   ├── UI.jsx          # Reusable UI components
│   │   │   └── InternForm.jsx  # Add/Edit modal form
│   │   ├── hooks/
│   │   │   └── useInterns.js   # Data fetching hook
│   │   ├── utils/
│   │   │   └── api.js          # API utility functions
│   │   ├── App.jsx             # Main app component
│   │   ├── main.jsx            # React entry point
│   │   └── index.css           # Global styles
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
│
├── package.json            # Root scripts with concurrently
└── README.md
```

---

## ⚙️ Prerequisites

- [Node.js](https://nodejs.org/) v18 or later
- [MongoDB](https://www.mongodb.com/try/download/community) running locally (default: `mongodb://localhost:27017`)
- npm v9+

---

## 🚀 Quick Start

### 1. Clone and install

```bash
git clone <repo-url>
cd intern-tracker
npm run install:all
```

### 2. Configure environment

```bash
cp server/.env.example server/.env
```

Edit `server/.env` if needed (defaults work for local MongoDB):

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/intern-tracker
NODE_ENV=development
```

### 3. Start both servers

```bash
npm run dev
```

This runs:
- **Backend** → http://localhost:5000
- **Frontend** → http://localhost:3000 (proxies `/api` to backend)

---

## 📡 API Reference

Base URL: `http://localhost:5000/api`

| Method | Endpoint             | Description                              |
|--------|----------------------|------------------------------------------|
| POST   | `/interns`           | Create a new intern                      |
| GET    | `/interns`           | List all interns (search, filter, page)  |
| GET    | `/interns/:id`       | Get a single intern by ID                |
| PATCH  | `/interns/:id`       | Update intern fields                     |
| DELETE | `/interns/:id`       | Delete an intern                         |
| GET    | `/health`            | Server health check                      |

### GET /api/interns — Query Parameters

| Param      | Type   | Default    | Description                          |
|------------|--------|------------|--------------------------------------|
| `search`   | string | `""`       | Search by name or email              |
| `role`     | string | —          | Filter: `Frontend`, `Backend`, `Fullstack` |
| `status`   | string | —          | Filter: `Applied`, `Interviewing`, `Hired`, `Rejected` |
| `page`     | number | `1`        | Page number                          |
| `limit`    | number | `10`       | Records per page (max 100)           |
| `sortBy`   | string | `createdAt`| Field to sort by                     |
| `sortOrder`| string | `desc`     | `asc` or `desc`                      |

### Example Requests

```bash
# Create intern
curl -X POST http://localhost:5000/api/interns \
  -H "Content-Type: application/json" \
  -d '{"name":"Jane Smith","email":"jane@example.com","role":"Frontend","status":"Applied","score":82}'

# List interns with filters
curl "http://localhost:5000/api/interns?role=Frontend&status=Hired&page=1&limit=5"

# Update intern
curl -X PATCH http://localhost:5000/api/interns/<id> \
  -H "Content-Type: application/json" \
  -d '{"status":"Hired","score":95}'

# Delete intern
curl -X DELETE http://localhost:5000/api/interns/<id>
```

---

## 🎨 Frontend Features

| Feature             | Description                                               |
|---------------------|-----------------------------------------------------------|
| **Intern Table**    | Paginated table with alternating rows and hover states    |
| **Search**          | Debounced search by name or email                         |
| **Filters**         | Filter by role and/or status                              |
| **Pagination**      | Smart page controls with record count                     |
| **Add Intern**      | Modal form with client-side validation                    |
| **Edit Intern**     | Pre-filled modal with same validation                     |
| **Delete Intern**   | Confirmation dialog before deletion                       |
| **Score Bar**       | Color-coded visual score indicator                        |
| **Status/Role Badges** | Color-coded inline labels                             |
| **Toast Notifications** | Auto-dismissing feedback messages                    |
| **Loading States**  | Spinners during all async operations                      |
| **Error Messages**  | Inline backend errors shown in form                       |

---

## 🗃 Data Model

```js
{
  name:      String,   // required, min 2 chars
  email:     String,   // required, unique, valid format
  role:      String,   // "Frontend" | "Backend" | "Fullstack"
  status:    String,   // "Applied" | "Interviewing" | "Hired" | "Rejected"
  score:     Number,   // 0–100
  createdAt: Date,     // auto
  updatedAt: Date      // auto
}
```

---

## 🛠 Error Handling

All errors return consistent JSON:

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    { "field": "email", "message": "This email is already in use" }
  ]
}
```

Handled cases:
- `400` Validation errors (missing fields, bad format)
- `400` Invalid MongoDB ObjectId
- `404` Intern not found
- `409` Duplicate email
- `500` Internal server errors

---

## 🔧 Individual Start Commands

```bash
# Backend only
cd server && npm run dev

# Frontend only
cd client && npm run dev
```
