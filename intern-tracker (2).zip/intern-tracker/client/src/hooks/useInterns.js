import { useState, useEffect, useCallback } from "react";
import { api } from "../utils/api";

export function useInterns(filters) {
  const [interns, setInterns] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchInterns = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await api.getInterns(filters);
      setInterns(result.data);
      setPagination(result.pagination);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [JSON.stringify(filters)]);

  useEffect(() => {
    fetchInterns();
  }, [fetchInterns]);

  return { interns, pagination, loading, error, refetch: fetchInterns };
}
