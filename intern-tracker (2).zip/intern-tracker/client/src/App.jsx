import React, { useState, useCallback, useRef, useEffect } from "react";
import { useInterns } from "./hooks/useInterns";
import { api } from "./utils/api";
import InternForm from "./components/InternForm";
import {
  StatusBadge,
  RoleBadge,
  ScoreBar,
  Spinner,
  Toast,
  ConfirmDialog,
} from "./components/UI";

const ROLES = ["Frontend", "Backend", "Fullstack"];
const STATUSES = ["Applied", "Interviewing", "Hired", "Rejected"];

// ─── Header ───────────────────────────────────────────────────────────────────
function Header({ onAdd }) {
  return (
    <header
      style={{
        borderBottom: "1px solid var(--border)",
        padding: "0 32px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        height: "64px",
        position: "sticky",
        top: 0,
        background: "var(--bg-base)",
        zIndex: 100,
        flexShrink: 0,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
        <div
          style={{
            width: "8px",
            height: "8px",
            background: "var(--accent)",
            boxShadow: "0 0 10px var(--accent)",
          }}
        />
        <div>
          <span
            style={{
              fontSize: "16px",
              fontWeight: 700,
              color: "var(--text-primary)",
              letterSpacing: "0.05em",
            }}
          >
            INTERN_TRACKER
          </span>
          <span
            style={{
              fontSize: "11px",
              color: "var(--text-muted)",
              marginLeft: "12px",
              letterSpacing: "0.08em",
            }}
          >
            v1.0
          </span>
        </div>
      </div>

      <button
        onClick={onAdd}
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
          padding: "8px 20px",
          background: "var(--accent)",
          border: "none",
          color: "var(--text-inverse)",
          fontFamily: "var(--font-mono)",
          fontSize: "12px",
          fontWeight: 700,
          cursor: "pointer",
          letterSpacing: "0.08em",
          textTransform: "uppercase",
          transition: "background 0.15s",
        }}
        onMouseEnter={(e) => (e.target.style.background = "var(--accent-dim)")}
        onMouseLeave={(e) => (e.target.style.background = "var(--accent)")}
      >
        <span style={{ fontSize: "16px", lineHeight: 1 }}>+</span>
        NEW INTERN
      </button>
    </header>
  );
}

// ─── Filters ──────────────────────────────────────────────────────────────────
function FilterBar({ filters, onChange }) {
  const [searchInput, setSearchInput] = useState(filters.search || "");
  const debounceRef = useRef(null);

  const handleSearch = (val) => {
    setSearchInput(val);
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      onChange({ search: val, page: 1 });
    }, 350);
  };

  const selectStyle = {
    background: "var(--bg-input)",
    border: "1px solid var(--border)",
    color: filters.role || filters.status ? "var(--text-primary)" : "var(--text-muted)",
    padding: "8px 12px",
    fontFamily: "var(--font-mono)",
    fontSize: "12px",
    cursor: "pointer",
    outline: "none",
    letterSpacing: "0.04em",
  };

  const hasFilters = filters.search || filters.role || filters.status;

  return (
    <div
      style={{
        display: "flex",
        gap: "12px",
        padding: "20px 32px",
        borderBottom: "1px solid var(--border)",
        alignItems: "center",
        flexWrap: "wrap",
      }}
    >
      {/* Search */}
      <div style={{ position: "relative", flex: "1", minWidth: "220px", maxWidth: "380px" }}>
        <span
          style={{
            position: "absolute",
            left: "12px",
            top: "50%",
            transform: "translateY(-50%)",
            color: "var(--text-muted)",
            fontSize: "13px",
          }}
        >
          ⌕
        </span>
        <input
          value={searchInput}
          onChange={(e) => handleSearch(e.target.value)}
          placeholder="Search name or email..."
          style={{
            width: "100%",
            background: "var(--bg-input)",
            border: "1px solid var(--border)",
            color: "var(--text-primary)",
            padding: "8px 12px 8px 32px",
            fontFamily: "var(--font-mono)",
            fontSize: "12px",
            outline: "none",
            letterSpacing: "0.04em",
          }}
          onFocus={(e) => (e.target.style.borderColor = "var(--accent-dim)")}
          onBlur={(e) => (e.target.style.borderColor = "var(--border)")}
        />
      </div>

      {/* Role filter */}
      <select
        value={filters.role || ""}
        onChange={(e) => onChange({ role: e.target.value, page: 1 })}
        style={selectStyle}
      >
        <option value="">All Roles</option>
        {ROLES.map((r) => (
          <option key={r} value={r}>
            {r}
          </option>
        ))}
      </select>

      {/* Status filter */}
      <select
        value={filters.status || ""}
        onChange={(e) => onChange({ status: e.target.value, page: 1 })}
        style={selectStyle}
      >
        <option value="">All Statuses</option>
        {STATUSES.map((s) => (
          <option key={s} value={s}>
            {s}
          </option>
        ))}
      </select>

      {/* Clear */}
      {hasFilters && (
        <button
          onClick={() => {
            setSearchInput("");
            onChange({ search: "", role: "", status: "", page: 1 });
          }}
          style={{
            background: "none",
            border: "1px solid var(--border)",
            color: "var(--text-muted)",
            padding: "8px 14px",
            fontFamily: "var(--font-mono)",
            fontSize: "11px",
            cursor: "pointer",
            letterSpacing: "0.06em",
            textTransform: "uppercase",
          }}
          onMouseEnter={(e) => (e.target.style.color = "var(--text-primary)")}
          onMouseLeave={(e) => (e.target.style.color = "var(--text-muted)")}
        >
          CLEAR ×
        </button>
      )}
    </div>
  );
}

// ─── Table ────────────────────────────────────────────────────────────────────
function InternTable({ interns, onEdit, onDelete, loading }) {
  const thStyle = {
    padding: "10px 16px",
    textAlign: "left",
    fontSize: "10px",
    color: "var(--text-muted)",
    letterSpacing: "0.14em",
    textTransform: "uppercase",
    fontWeight: 600,
    borderBottom: "1px solid var(--border)",
    whiteSpace: "nowrap",
    background: "var(--bg-panel)",
  };

  if (loading) {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: "12px",
          padding: "80px 32px",
          color: "var(--text-muted)",
          fontSize: "13px",
        }}
      >
        <Spinner size={18} />
        LOADING RECORDS...
      </div>
    );
  }

  if (!interns.length) {
    return (
      <div
        style={{
          padding: "80px 32px",
          textAlign: "center",
          color: "var(--text-muted)",
          fontSize: "13px",
          letterSpacing: "0.08em",
        }}
      >
        <div style={{ fontSize: "32px", marginBottom: "12px", opacity: 0.3 }}>
          ∅
        </div>
        NO RECORDS FOUND
      </div>
    );
  }

  return (
    <div style={{ overflowX: "auto" }}>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          tableLayout: "auto",
        }}
      >
        <thead>
          <tr>
            <th style={thStyle}>Name</th>
            <th style={thStyle}>Email</th>
            <th style={thStyle}>Role</th>
            <th style={thStyle}>Status</th>
            <th style={{ ...thStyle, minWidth: "140px" }}>Score</th>
            <th style={thStyle}>Created</th>
            <th style={{ ...thStyle, textAlign: "right" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {interns.map((intern, idx) => (
            <tr
              key={intern._id}
              style={{
                borderBottom: "1px solid var(--border)",
                background:
                  idx % 2 === 0 ? "var(--bg-base)" : "var(--bg-panel)",
                transition: "background 0.1s",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background = "var(--bg-hover)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background =
                  idx % 2 === 0 ? "var(--bg-base)" : "var(--bg-panel)")
              }
            >
              <td
                style={{
                  padding: "12px 16px",
                  fontSize: "13px",
                  fontWeight: 600,
                  color: "var(--text-primary)",
                  whiteSpace: "nowrap",
                }}
              >
                {intern.name}
              </td>
              <td
                style={{
                  padding: "12px 16px",
                  fontSize: "12px",
                  color: "var(--text-secondary)",
                }}
              >
                {intern.email}
              </td>
              <td style={{ padding: "12px 16px" }}>
                <RoleBadge role={intern.role} />
              </td>
              <td style={{ padding: "12px 16px" }}>
                <StatusBadge status={intern.status} />
              </td>
              <td style={{ padding: "12px 16px", minWidth: "140px" }}>
                <ScoreBar score={intern.score} />
              </td>
              <td
                style={{
                  padding: "12px 16px",
                  fontSize: "11px",
                  color: "var(--text-muted)",
                  whiteSpace: "nowrap",
                }}
              >
                {new Date(intern.createdAt).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                })}
              </td>
              <td style={{ padding: "12px 16px", textAlign: "right", whiteSpace: "nowrap" }}>
                <button
                  onClick={() => onEdit(intern)}
                  title="Edit"
                  style={{
                    background: "none",
                    border: "1px solid var(--border)",
                    color: "var(--text-secondary)",
                    padding: "5px 12px",
                    fontFamily: "var(--font-mono)",
                    fontSize: "11px",
                    cursor: "pointer",
                    letterSpacing: "0.06em",
                    marginRight: "8px",
                    textTransform: "uppercase",
                    transition: "all 0.15s",
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.borderColor = "var(--accent-dim)";
                    e.target.style.color = "var(--accent)";
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.borderColor = "var(--border)";
                    e.target.style.color = "var(--text-secondary)";
                  }}
                >
                  EDIT
                </button>
                <button
                  onClick={() => onDelete(intern)}
                  title="Delete"
                  style={{
                    background: "none",
                    border: "1px solid var(--border)",
                    color: "var(--text-secondary)",
                    padding: "5px 12px",
                    fontFamily: "var(--font-mono)",
                    fontSize: "11px",
                    cursor: "pointer",
                    letterSpacing: "0.06em",
                    textTransform: "uppercase",
                    transition: "all 0.15s",
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.borderColor = "var(--danger)";
                    e.target.style.color = "var(--danger)";
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.borderColor = "var(--border)";
                    e.target.style.color = "var(--text-secondary)";
                  }}
                >
                  DEL
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Pagination ───────────────────────────────────────────────────────────────
function Pagination({ pagination, onPageChange }) {
  if (!pagination || pagination.totalPages <= 1) return null;
  const { page, totalPages, total, limit } = pagination;
  const start = (page - 1) * limit + 1;
  const end = Math.min(page * limit, total);

  const btnStyle = (active) => ({
    padding: "6px 12px",
    background: active ? "var(--accent)" : "none",
    border: `1px solid ${active ? "var(--accent)" : "var(--border)"}`,
    color: active ? "var(--text-inverse)" : "var(--text-secondary)",
    fontFamily: "var(--font-mono)",
    fontSize: "12px",
    cursor: "pointer",
    fontWeight: active ? 700 : 400,
    minWidth: "36px",
  });

  const pages = [];
  for (let i = 1; i <= totalPages; i++) {
    if (
      i === 1 ||
      i === totalPages ||
      (i >= page - 1 && i <= page + 1)
    ) {
      pages.push(i);
    } else if (pages[pages.length - 1] !== "...") {
      pages.push("...");
    }
  }

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "16px 32px",
        borderTop: "1px solid var(--border)",
        flexWrap: "wrap",
        gap: "12px",
      }}
    >
      <span
        style={{
          fontSize: "11px",
          color: "var(--text-muted)",
          letterSpacing: "0.06em",
        }}
      >
        SHOWING {start}–{end} OF {total} RECORDS
      </span>
      <div style={{ display: "flex", gap: "4px" }}>
        <button
          onClick={() => onPageChange(page - 1)}
          disabled={page === 1}
          style={{
            ...btnStyle(false),
            opacity: page === 1 ? 0.3 : 1,
            cursor: page === 1 ? "not-allowed" : "pointer",
          }}
        >
          ‹
        </button>
        {pages.map((p, i) =>
          p === "..." ? (
            <span
              key={`dots-${i}`}
              style={{
                padding: "6px 4px",
                color: "var(--text-muted)",
                fontSize: "12px",
              }}
            >
              ...
            </span>
          ) : (
            <button
              key={p}
              onClick={() => onPageChange(p)}
              style={btnStyle(p === page)}
            >
              {p}
            </button>
          )
        )}
        <button
          onClick={() => onPageChange(page + 1)}
          disabled={page === totalPages}
          style={{
            ...btnStyle(false),
            opacity: page === totalPages ? 0.3 : 1,
            cursor: page === totalPages ? "not-allowed" : "pointer",
          }}
        >
          ›
        </button>
      </div>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [filters, setFilters] = useState({
    search: "",
    role: "",
    status: "",
    page: 1,
    limit: 10,
  });

  const { interns, pagination, loading, error, refetch } = useInterns(filters);

  // Modal state
  const [showForm, setShowForm] = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  // Action state
  const [formLoading, setFormLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [formError, setFormError] = useState(null);
  const [formErrors, setFormErrors] = useState(null);
  const [toast, setToast] = useState(null);

  const showToast = (message, type = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  const updateFilters = useCallback((patch) => {
    setFilters((prev) => ({ ...prev, ...patch }));
  }, []);

  const handleAdd = () => {
    setEditTarget(null);
    setFormError(null);
    setFormErrors(null);
    setShowForm(true);
  };

  const handleEdit = (intern) => {
    setEditTarget(intern);
    setFormError(null);
    setFormErrors(null);
    setShowForm(true);
  };

  const handleFormSubmit = async (values) => {
    setFormLoading(true);
    setFormError(null);
    setFormErrors(null);
    try {
      if (editTarget) {
        await api.updateIntern(editTarget._id, values);
        showToast("Intern updated successfully.");
      } else {
        await api.createIntern(values);
        showToast("Intern added successfully.");
      }
      setShowForm(false);
      refetch();
    } catch (err) {
      setFormError(err.message);
      setFormErrors(err.errors);
    } finally {
      setFormLoading(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;
    setDeleteLoading(true);
    try {
      await api.deleteIntern(deleteTarget._id);
      showToast("Intern deleted.", "info");
      setDeleteTarget(null);
      refetch();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setDeleteLoading(false);
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        background: "var(--bg-base)",
      }}
    >
      <Header onAdd={handleAdd} />

      {/* Stats Bar */}
      {pagination && !loading && (
        <div
          style={{
            display: "flex",
            gap: "0",
            borderBottom: "1px solid var(--border)",
            overflowX: "auto",
          }}
        >
          {[
            {
              label: "Total",
              value: pagination.total,
              color: "var(--text-primary)",
            },
            {
              label: "Page",
              value: `${pagination.page} / ${pagination.totalPages}`,
              color: "var(--text-secondary)",
            },
          ].map((stat) => (
            <div
              key={stat.label}
              style={{
                padding: "12px 24px",
                borderRight: "1px solid var(--border)",
                display: "flex",
                flexDirection: "column",
                gap: "2px",
              }}
            >
              <span
                style={{
                  fontSize: "10px",
                  color: "var(--text-muted)",
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                }}
              >
                {stat.label}
              </span>
              <span
                style={{
                  fontSize: "18px",
                  fontWeight: 700,
                  color: stat.color,
                  letterSpacing: "0.03em",
                }}
              >
                {stat.value}
              </span>
            </div>
          ))}
        </div>
      )}

      <FilterBar filters={filters} onChange={updateFilters} />

      {/* Error state */}
      {error && !loading && (
        <div
          style={{
            margin: "24px 32px",
            padding: "16px",
            background: "var(--danger-bg)",
            border: "1px solid var(--danger)",
            color: "var(--danger)",
            fontSize: "13px",
            display: "flex",
            alignItems: "center",
            gap: "10px",
          }}
        >
          <span>⚠</span> {error}
          <button
            onClick={refetch}
            style={{
              marginLeft: "auto",
              background: "none",
              border: "1px solid var(--danger)",
              color: "var(--danger)",
              padding: "4px 12px",
              fontFamily: "var(--font-mono)",
              fontSize: "11px",
              cursor: "pointer",
            }}
          >
            RETRY
          </button>
        </div>
      )}

      <div style={{ flex: 1 }}>
        <InternTable
          interns={interns}
          loading={loading}
          onEdit={handleEdit}
          onDelete={setDeleteTarget}
        />
      </div>

      <Pagination
        pagination={pagination}
        onPageChange={(p) => updateFilters({ page: p })}
      />

      {/* Footer */}
      <div
        style={{
          borderTop: "1px solid var(--border)",
          padding: "12px 32px",
          fontSize: "10px",
          color: "var(--text-muted)",
          letterSpacing: "0.08em",
          display: "flex",
          justifyContent: "space-between",
        }}
      >
        <span>INTERN_TRACKER © {new Date().getFullYear()}</span>
        <span>MERN STACK</span>
      </div>

      {/* Modals */}
      {showForm && (
        <InternForm
          intern={editTarget}
          onSubmit={handleFormSubmit}
          onCancel={() => setShowForm(false)}
          loading={formLoading}
          apiError={formError}
          apiErrors={formErrors}
        />
      )}

      {deleteTarget && (
        <ConfirmDialog
          title={`Delete ${deleteTarget.name}?`}
          message={`This will permanently remove ${deleteTarget.name} (${deleteTarget.email}) from the system. This action cannot be undone.`}
          onConfirm={handleDeleteConfirm}
          onCancel={() => setDeleteTarget(null)}
          loading={deleteLoading}
        />
      )}

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}
