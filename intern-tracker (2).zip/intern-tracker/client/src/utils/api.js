const BASE_URL = "/api/interns";

async function request(url, options = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });
  const data = await res.json();
  if (!res.ok) {
    const error = new Error(data.message || "Request failed");
    error.errors = data.errors || null;
    error.status = res.status;
    throw error;
  }
  return data;
}

export const api = {
  getInterns: (params = {}) => {
    const query = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== "" && v != null)
    ).toString();
    return request(`${BASE_URL}${query ? `?${query}` : ""}`);
  },

  getIntern: (id) => request(`${BASE_URL}/${id}`),

  createIntern: (body) =>
    request(BASE_URL, { method: "POST", body: JSON.stringify(body) }),

  updateIntern: (id, body) =>
    request(`${BASE_URL}/${id}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  deleteIntern: (id) => request(`${BASE_URL}/${id}`, { method: "DELETE" }),
};
