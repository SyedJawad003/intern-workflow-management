import React, { useState, useEffect } from "react";
import { Field, Input, Select, ErrorBlock, Spinner } from "./UI";

const ROLES = ["Frontend", "Backend", "Fullstack"];
const STATUSES = ["Applied", "Interviewing", "Hired", "Rejected"];

const EMPTY = {
  name: "",
  email: "",
  role: "",
  status: "",
  score: "",
};

function validate(values) {
  const errors = {};
  if (!values.name || values.name.trim().length < 2)
    errors.name = "Name must be at least 2 characters";
  if (!values.email || !/^\S+@\S+\.\S+$/.test(values.email))
    errors.email = "Valid email required";
  if (!values.role) errors.role = "Select a role";
  if (!values.status) errors.status = "Select a status";
  const score = Number(values.score);
  if (values.score === "" || isNaN(score) || score < 0 || score > 100)
    errors.score = "Score must be 0–100";
  return errors;
}

export default function InternForm({ intern, onSubmit, onCancel, loading, apiError, apiErrors }) {
  const [values, setValues] = useState(EMPTY);
  const [fieldErrors, setFieldErrors] = useState({});
  const [touched, setTouched] = useState({});

  useEffect(() => {
    if (intern) {
      setValues({
        name: intern.name || "",
        email: intern.email || "",
        role: intern.role || "",
        status: intern.status || "",
        score: intern.score ?? "",
      });
    } else {
      setValues(EMPTY);
    }
    setFieldErrors({});
    setTouched({});
  }, [intern]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    const next = { ...values, [name]: value };
    setValues(next);
    if (touched[name]) {
      const errs = validate(next);
      setFieldErrors((prev) => ({ ...prev, [name]: errs[name] || null }));
    }
  };

  const handleBlur = (e) => {
    const { name } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    const errs = validate(values);
    setFieldErrors((prev) => ({ ...prev, [name]: errs[name] || null }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const allTouched = Object.fromEntries(
      Object.keys(values).map((k) => [k, true])
    );
    setTouched(allTouched);
    const errs = validate(values);
    setFieldErrors(errs);
    if (Object.keys(errs).length > 0) return;
    onSubmit({ ...values, score: Number(values.score) });
  };

  const isEdit = Boolean(intern);

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.8)",
        zIndex: 1000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px",
      }}
      onClick={onCancel}
    >
      <div
        style={{
          background: "var(--bg-card)",
          border: "1px solid var(--border-active)",
          padding: "32px",
          maxWidth: "480px",
          width: "100%",
          boxShadow: "0 0 60px rgba(0,255,136,0.06)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div style={{ marginBottom: "28px" }}>
          <div
            style={{
              fontSize: "11px",
              color: "var(--accent)",
              letterSpacing: "0.15em",
              textTransform: "uppercase",
              fontWeight: 700,
              marginBottom: "6px",
            }}
          >
            {isEdit ? "// EDIT RECORD" : "// NEW RECORD"}
          </div>
          <div
            style={{ fontSize: "20px", fontWeight: 700, color: "var(--text-primary)" }}
          >
            {isEdit ? "Update Intern" : "Add Intern"}
          </div>
        </div>

        <ErrorBlock message={apiError} errors={apiErrors} />

        <form onSubmit={handleSubmit} noValidate>
          <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
            <Field label="Name" error={fieldErrors.name}>
              <Input
                name="name"
                value={values.name}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="Jane Smith"
                error={fieldErrors.name}
              />
            </Field>

            <Field label="Email" error={fieldErrors.email}>
              <Input
                name="email"
                type="email"
                value={values.email}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="jane@example.com"
                error={fieldErrors.email}
              />
            </Field>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px" }}>
              <Field label="Role" error={fieldErrors.role}>
                <Select
                  name="role"
                  value={values.role}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  error={fieldErrors.role}
                >
                  <option value="">Select role</option>
                  {ROLES.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </Select>
              </Field>

              <Field label="Status" error={fieldErrors.status}>
                <Select
                  name="status"
                  value={values.status}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  error={fieldErrors.status}
                >
                  <option value="">Select status</option>
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>

            <Field label="Score (0–100)" error={fieldErrors.score}>
              <Input
                name="score"
                type="number"
                min="0"
                max="100"
                value={values.score}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="85"
                error={fieldErrors.score}
              />
            </Field>
          </div>

          <div style={{ display: "flex", gap: "12px", marginTop: "28px" }}>
            <button
              type="button"
              onClick={onCancel}
              disabled={loading}
              style={{
                flex: 1,
                padding: "11px",
                background: "none",
                border: "1px solid var(--border-active)",
                color: "var(--text-secondary)",
                fontFamily: "var(--font-mono)",
                fontSize: "13px",
                cursor: "pointer",
                fontWeight: 600,
                letterSpacing: "0.05em",
              }}
            >
              CANCEL
            </button>
            <button
              type="submit"
              disabled={loading}
              style={{
                flex: 1,
                padding: "11px",
                background: loading ? "var(--accent-dim)" : "var(--accent)",
                border: "1px solid var(--accent)",
                color: "var(--text-inverse)",
                fontFamily: "var(--font-mono)",
                fontSize: "13px",
                cursor: loading ? "not-allowed" : "pointer",
                fontWeight: 700,
                letterSpacing: "0.05em",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
              }}
            >
              {loading && <Spinner size={14} />}
              {loading ? "SAVING..." : isEdit ? "SAVE CHANGES" : "ADD INTERN"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
