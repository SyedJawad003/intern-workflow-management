import React from "react";

// ─── Badge ────────────────────────────────────────────────────────────────────
const STATUS_COLORS = {
  Applied: { bg: "rgba(255,170,0,0.1)", border: "#ffaa00", text: "#ffaa00" },
  Interviewing: {
    bg: "rgba(0,170,255,0.1)",
    border: "#00aaff",
    text: "#00aaff",
  },
  Hired: { bg: "rgba(0,255,136,0.1)", border: "#00ff88", text: "#00ff88" },
  Rejected: { bg: "rgba(255,59,59,0.1)", border: "#ff3b3b", text: "#ff3b3b" },
};

const ROLE_COLORS = {
  Frontend: {
    bg: "rgba(255,107,157,0.1)",
    border: "#ff6b9d",
    text: "#ff6b9d",
  },
  Backend: { bg: "rgba(155,107,255,0.1)", border: "#9b6bff", text: "#9b6bff" },
  Fullstack: {
    bg: "rgba(107,255,255,0.1)",
    border: "#6bffff",
    text: "#6bffff",
  },
};

export function StatusBadge({ status }) {
  const colors = STATUS_COLORS[status] || {};
  return (
    <span
      style={{
        display: "inline-block",
        padding: "2px 8px",
        background: colors.bg,
        border: `1px solid ${colors.border}`,
        color: colors.text,
        fontSize: "11px",
        fontFamily: "var(--font-mono)",
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        fontWeight: 600,
      }}
    >
      {status}
    </span>
  );
}

export function RoleBadge({ role }) {
  const colors = ROLE_COLORS[role] || {};
  return (
    <span
      style={{
        display: "inline-block",
        padding: "2px 8px",
        background: colors.bg,
        border: `1px solid ${colors.border}`,
        color: colors.text,
        fontSize: "11px",
        fontFamily: "var(--font-mono)",
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        fontWeight: 600,
      }}
    >
      {role}
    </span>
  );
}

// ─── Score Bar ─────────────────────────────────────────────────────────────────
export function ScoreBar({ score }) {
  const pct = Math.min(100, Math.max(0, score));
  const color =
    pct >= 75
      ? "var(--accent)"
      : pct >= 50
      ? "var(--warning)"
      : pct >= 25
      ? "#ff8c00"
      : "var(--danger)";

  return (
    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
      <div
        style={{
          flex: 1,
          height: "4px",
          background: "var(--border)",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            left: 0,
            top: 0,
            height: "100%",
            width: `${pct}%`,
            background: color,
            transition: "width 0.3s ease",
          }}
        />
      </div>
      <span
        style={{
          fontSize: "12px",
          color: color,
          fontWeight: 600,
          minWidth: "32px",
          textAlign: "right",
        }}
      >
        {score}
      </span>
    </div>
  );
}

// ─── Spinner ──────────────────────────────────────────────────────────────────
export function Spinner({ size = 20 }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        border: `2px solid var(--border)`,
        borderTop: `2px solid var(--accent)`,
        borderRadius: "50%",
        animation: "spin 0.7s linear infinite",
        display: "inline-block",
      }}
    />
  );
}

// Inject keyframes once
if (typeof document !== "undefined") {
  const style = document.createElement("style");
  style.textContent = `@keyframes spin { to { transform: rotate(360deg); } }`;
  document.head.appendChild(style);
}

// ─── Toast ────────────────────────────────────────────────────────────────────
export function Toast({ message, type = "success", onClose }) {
  const colors = {
    success: { bg: "var(--accent-glow)", border: "var(--accent)", text: "var(--accent)" },
    error: { bg: "var(--danger-bg)", border: "var(--danger)", text: "var(--danger)" },
    info: { bg: "var(--info-bg)", border: "var(--info)", text: "var(--info)" },
  };
  const c = colors[type] || colors.info;

  return (
    <div
      style={{
        position: "fixed",
        bottom: "24px",
        right: "24px",
        zIndex: 9999,
        padding: "12px 20px",
        background: "var(--bg-card)",
        border: `1px solid ${c.border}`,
        color: c.text,
        fontFamily: "var(--font-mono)",
        fontSize: "13px",
        display: "flex",
        alignItems: "center",
        gap: "12px",
        boxShadow: `0 0 20px ${c.bg}`,
        animation: "slideUp 0.2s ease",
        maxWidth: "380px",
      }}
    >
      <span>{message}</span>
      <button
        onClick={onClose}
        style={{
          background: "none",
          border: "none",
          color: c.text,
          cursor: "pointer",
          fontSize: "16px",
          lineHeight: 1,
          opacity: 0.7,
        }}
      >
        ×
      </button>
      <style>{`@keyframes slideUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }`}</style>
    </div>
  );
}

// ─── Error Block ──────────────────────────────────────────────────────────────
export function ErrorBlock({ message, errors }) {
  if (!message) return null;
  return (
    <div
      style={{
        padding: "12px 16px",
        background: "var(--danger-bg)",
        border: "1px solid var(--danger)",
        color: "var(--danger)",
        fontSize: "13px",
        marginBottom: "16px",
      }}
    >
      <div style={{ fontWeight: 600, marginBottom: errors?.length ? "8px" : 0 }}>
        {message}
      </div>
      {errors?.map((e, i) => (
        <div key={i} style={{ opacity: 0.85, fontSize: "12px" }}>
          › {e.field}: {e.message}
        </div>
      ))}
    </div>
  );
}

// ─── Confirm Dialog ───────────────────────────────────────────────────────────
export function ConfirmDialog({ title, message, onConfirm, onCancel, loading }) {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.75)",
        zIndex: 1000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px",
      }}
      onClick={onCancel}
    >
      <div
        style={{
          background: "var(--bg-card)",
          border: "1px solid var(--danger)",
          padding: "32px",
          maxWidth: "400px",
          width: "100%",
          boxShadow: "0 0 40px rgba(255,59,59,0.15)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div
          style={{
            fontSize: "11px",
            color: "var(--danger)",
            letterSpacing: "0.15em",
            textTransform: "uppercase",
            fontWeight: 700,
            marginBottom: "8px",
          }}
        >
          ⚠ CONFIRM ACTION
        </div>
        <div
          style={{
            fontSize: "16px",
            fontWeight: 700,
            color: "var(--text-primary)",
            marginBottom: "12px",
          }}
        >
          {title}
        </div>
        <div
          style={{
            color: "var(--text-secondary)",
            fontSize: "13px",
            marginBottom: "28px",
            lineHeight: 1.7,
          }}
        >
          {message}
        </div>
        <div style={{ display: "flex", gap: "12px" }}>
          <button
            onClick={onCancel}
            disabled={loading}
            style={{
              flex: 1,
              padding: "10px",
              background: "none",
              border: "1px solid var(--border-active)",
              color: "var(--text-secondary)",
              fontFamily: "var(--font-mono)",
              fontSize: "13px",
              cursor: "pointer",
              fontWeight: 600,
              letterSpacing: "0.05em",
            }}
          >
            CANCEL
          </button>
          <button
            onClick={onConfirm}
            disabled={loading}
            style={{
              flex: 1,
              padding: "10px",
              background: "var(--danger)",
              border: "1px solid var(--danger)",
              color: "#fff",
              fontFamily: "var(--font-mono)",
              fontSize: "13px",
              cursor: loading ? "not-allowed" : "pointer",
              fontWeight: 700,
              letterSpacing: "0.05em",
              opacity: loading ? 0.7 : 1,
            }}
          >
            {loading ? "DELETING..." : "DELETE"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Field Input ──────────────────────────────────────────────────────────────
export function Field({ label, error, children }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
      <label
        style={{
          fontSize: "11px",
          color: "var(--text-secondary)",
          letterSpacing: "0.1em",
          textTransform: "uppercase",
          fontWeight: 600,
        }}
      >
        {label}
      </label>
      {children}
      {error && (
        <span style={{ fontSize: "11px", color: "var(--danger)" }}>{error}</span>
      )}
    </div>
  );
}

const inputStyle = {
  background: "var(--bg-input)",
  border: "1px solid var(--border)",
  color: "var(--text-primary)",
  padding: "9px 12px",
  fontFamily: "var(--font-mono)",
  fontSize: "13px",
  width: "100%",
  transition: "border-color 0.15s",
};

export function Input({ error, ...props }) {
  return (
    <input
      style={{
        ...inputStyle,
        borderColor: error ? "var(--danger)" : "var(--border)",
      }}
      onFocus={(e) => {
        e.target.style.borderColor = error
          ? "var(--danger)"
          : "var(--accent-dim)";
      }}
      onBlur={(e) => {
        e.target.style.borderColor = error ? "var(--danger)" : "var(--border)";
      }}
      {...props}
    />
  );
}

export function Select({ error, children, ...props }) {
  return (
    <select
      style={{
        ...inputStyle,
        borderColor: error ? "var(--danger)" : "var(--border)",
        cursor: "pointer",
      }}
      onFocus={(e) => {
        e.target.style.borderColor = error
          ? "var(--danger)"
          : "var(--accent-dim)";
      }}
      onBlur={(e) => {
        e.target.style.borderColor = error ? "var(--danger)" : "var(--border)";
      }}
      {...props}
    >
      {children}
    </select>
  );
}
